# Navigation bar structure

<hr>
<h3 style="color: rebeccapurple">Navigation</h3>
<ul>
    <li>Home</li>
    <li>About</li>
    <li>Articles</li>
</ul>
<h3 style="color: rebeccapurple">Blog</h3>
<ul>
    <li>Articles</li>
    <li>Categories</li>
    <li>Search an article</li>
</ul>
<h3 style="color: rebeccapurple">Study</h3>
<ul>
    <li>Books</li>
    <li>Readings</li>
    <li>Podcasts</li>
    <li>Talks</li>
    <li>Tutorials</li>
</ul>
<h3 style="color: rebeccapurple">Entertainment</h3>
<ul>
    <li>Musics</li>
    <li>Gallery</li>
</ul>
<h3 style="color: rebeccapurple">Devices</h3>
<ul>
    <li>My setup</li>
    <li>Keyboards</li>
    <li>Templates</li>
</ul>
<h3 style="color: rebeccapurple">Socials</h3>
<ul>
    <li>Github</li>
    <li>Linkedin</li>
    <li>Telegram</li>
    <li>Contact</li>
</ul>
<h3 style="color: rebeccapurple">Other</h3>
<ul>
    <li>Extra</li>
</ul>